package tthbase.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Durability;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

import tthbase.client.HTableGetByIndex;
import tthbase.util.HIndexConstantsAndUtils;

public class PutWrong {

	static String filePath = "/opt/qhl/test-data/xaa1000.txt";
	static final boolean RYW = false;
	static boolean wal = false;
	BlockingQueue<Put> queue = new LinkedBlockingQueue<Put>(1000000);
	
	int writeNum = 2;
	static String[] SessionIDs = new String[10];
	static final int clientNum = 2;
	
	AtomicInteger writeCount = new AtomicInteger(0);
	
	static String testTableName = "testtable8";
	static String columnFamily = "cf";
	static String indexedColumnName = "c5";
	static String queryValue = "5-LOW";
	
	
	
	

    public static void initCoProcessors(Configuration conf, String coprocessorJarLoc, HTableGetByIndex htable) throws Exception {
       int coprocessorIndex = 1;
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.IndexObserverwReadRepair");
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.PhysicalDeletionInCompaction");
       htable.configPolicy(HTableGetByIndex.PLY_READCHECK);
    }
    
    
    
	public static void main(String[] args) throws Exception {
		
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.zookeeper.quorum", "data1,data2,data6,data7,data8");  
	    conf.set("hbase.zookeeper.property.clientPort", "2181");  

		if (args.length <= 0) {
			System.err.println("format: java -cp <classpath> tthbase.client.Demo <where coproc.jar is>");
			System.err.println(
					"example: java -cp build/jar/libDeli-client.jar:conf:lib/hbase-binding-0.1.4.jar tthbase.client.Demo  /root/app/deli/build/jar/libDeli-coproc.jar ");
			return;
		}
		String locCoproc = args[0];
		String coprocessorJarLoc = "file:" + locCoproc;
		

		initTables(conf, testTableName, columnFamily, indexedColumnName);
		
		HTableGetByIndex htable = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
		initCoProcessors(conf, coprocessorJarLoc, htable);
                   
		
		PutAccuracy test = new PutAccuracy();
		
		test.start();
	}
	
	private byte[] reverse(byte[] b){
		for (int i = 0, j = b.length - 1; i < j; i++, j--){
			byte tmp = b[i];
			b[i] = b[j];
			b[j] = tmp;
		}
		return b;
	}
	
	private void write(int writeNum){
		int readNum = 0;
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(filePath)));
			String line = null, col[] = null;
			
			while ((line = reader.readLine()) != null && (readNum < 1000000)) {
				col = line.split(";");
			//	Put put = new Put(reverse(Bytes.toBytes(col[0])));
				Put put = new Put(reverse(Bytes.toBytes("1")));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c1"), Bytes.toBytes(Integer.valueOf(col[1])));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c2"), Bytes.toBytes(col[2]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c3"), Bytes.toBytes(col[3]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c4"), Bytes.toBytes(col[4]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c5"), Bytes.toBytes(col[5]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c6"), Bytes.toBytes(col[6]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c7"), Bytes.toBytes(Integer.valueOf(col[7])));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c8"), Bytes.toBytes(col[8]));
				
				if (!wal) {
					put.setDurability(Durability.SKIP_WAL);
				}
				queue.put(put);
				readNum++;
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e){
			e.printStackTrace();
		}
	}
	
	public static void initTables(Configuration conf, String testTableName, String columnFamily, String indexedColumnName) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        
/*        if (admin.isTableAvailable(testTableName) && admin.isTableAvailable(indexTableName)) {
        	admin.disableTable(testTableName);
        	admin.deleteTable(testTableName);
        	admin.disableTable(indexTableName);
        	admin.deleteTable(indexTableName);
        }*/
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
    }
	
	
	
	
	
	
	public void start() throws IOException {

		Configuration conf = HBaseConfiguration.create();
		HTableGetByIndex table = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
		table.configPolicy(HTableGetByIndex.PLY_FASTREAD);
		
		write(writeNum);
		System.out.println("queue:" + queue.size() + ", wait for 1 second...");
		for (int i = 0; i < writeNum; i++) {
			Put put = null;
			try {
				put = queue.poll(1, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (put == null) {
				break;
			}
			table.put(put);
			System.out.println("Queue " + (i + 1) + " has been put");
		    table.configPolicy(HTableGetByIndex.PLY_FASTREAD);
		    List<byte[]> res = table.getByIndex(Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName), Bytes.toBytes(queryValue));
		    assert(res != null && res.size() != 0);
		    System.out.println("Result is " + Bytes.toString(res.get(0)));
		}
	}
}
