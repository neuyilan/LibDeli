package tthbase.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Durability;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;

import tthbase.client.HTableGetByIndex;
import tthbase.util.HIndexConstantsAndUtils;
import tthbase.util.Session;
import tthbase.util.SessionGenerate;
import tthbase.util.SessionMap;

public class PutAccuracy {

	static String filePath = "/opt/qhl/test-data/xaa1000.txt";
	static final boolean RYW = false;
	static boolean wal = false;
	BlockingQueue<Put> queue = new LinkedBlockingQueue<Put>(1000000);
	
	Reader[] reader;
	int writeNum = 10000;
	static String[] SessionIDs = new String[10];
	static final int clientNum = 2;
	
	AtomicInteger writeCount = new AtomicInteger(0);
	
	static String testTableName = "testtable3";
	static String columnFamily = "cf";
	static String indexedColumnName = "c3";
	static String indexedColumnName2 = "c4";
	static String indexedColumnName3 = "c5";
	
	
	
	

    public static void initCoProcessors(Configuration conf, String coprocessorJarLoc, HTableGetByIndex htable) throws Exception {
       int coprocessorIndex = 1;
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.IndexObserverwReadRepair");
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.PhysicalDeletionInCompaction");
       htable.configPolicy(HTableGetByIndex.PLY_READCHECK);
    }
    
    
    
	public static void main(String[] args) throws Exception {
		
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.zookeeper.quorum", "data1,data2,data6,data7,data8");  
	    conf.set("hbase.zookeeper.property.clientPort", "2181");  

		if (args.length <= 0) {
			System.err.println("format: java -cp <classpath> tthbase.client.Demo <where coproc.jar is>");
			System.err.println(
					"example: java -cp build/jar/libDeli-client.jar:conf:lib/hbase-binding-0.1.4.jar tthbase.client.Demo  /root/app/deli/build/jar/libDeli-coproc.jar ");
			return;
		}
		String locCoproc = args[0];
		String coprocessorJarLoc = "file:" + locCoproc;
		
		initTables(conf, testTableName, columnFamily, indexedColumnName);
//		initTables2(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName2);
//		initTables3(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName2, indexedColumnName3);
		
		HTableGetByIndex htable = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
		initCoProcessors(conf, coprocessorJarLoc, htable);
	
		for (int i = 0; i < clientNum; i++) {
			SessionIDs[i] = SessionGenerate.generateSession();
		}
		
		PutAccuracy test = new PutAccuracy();
		
		test.start();
	}
	
	private byte[] reverse(byte[] b){
		for (int i = 0, j = b.length - 1; i < j; i++, j--){
			byte tmp = b[i];
			b[i] = b[j];
			b[j] = tmp;
		}
		return b;
	}
	
	private void write(int writeNum){
		int readNum = 0;
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(filePath)));
			String line = null, col[] = null;
			
			while ((line = reader.readLine()) != null && (readNum < 1000000)) {
				col = line.split(";");
			//	Put put = new Put(reverse(Bytes.toBytes(col[0])));
				Put put = new Put(reverse(Bytes.toBytes("1")));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c1"), Bytes.toBytes(Integer.valueOf(col[1])));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c2"), Bytes.toBytes(col[2]));
			//	put.add(Bytes.toBytes("cf"), Bytes.toBytes("c3"), Bytes.toBytes(col[3]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c3"), Bytes.toBytes(Integer.toString(readNum)));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c4"), Bytes.toBytes(col[4]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c5"), Bytes.toBytes(col[5]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c6"), Bytes.toBytes(col[6]));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c7"), Bytes.toBytes(Integer.valueOf(col[7])));
				put.add(Bytes.toBytes("cf"), Bytes.toBytes("c8"), Bytes.toBytes(col[8]));
				
				if (!wal) {
					put.setDurability(Durability.SKIP_WAL);
				}
				queue.put(put);
				readNum++;
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e){
			e.printStackTrace();
		}
	}
	
	public static void initTables(Configuration conf, String testTableName, String columnFamily, String indexedColumnName) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        
/*        if (admin.isTableAvailable(testTableName) && admin.isTableAvailable(indexTableName)) {
        	admin.disableTable(testTableName);
        	admin.deleteTable(testTableName);
        	admin.disableTable(indexTableName);
        	admin.deleteTable(indexTableName);
        }*/
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
    }
	
	public static void initTables2(Configuration conf, String testTableName, String columnFamily, String indexedColumnName, String indexedColumnName2) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        byte[] indexTableName2 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName2)/*TODO column family in index table*/);
        
/*        if (admin.isTableAvailable(testTableName) && admin.isTableAvailable(indexTableName)) {
        	admin.disableTable(testTableName);
        	admin.deleteTable(testTableName);
        	admin.disableTable(indexTableName);
        	admin.deleteTable(indexTableName);
        }*/
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName,indexedColumnName2});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName2)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName2, Bytes.toBytes(columnFamily));
        }
    }
	
	public static void initTables3(Configuration conf, String testTableName, String columnFamily, String indexedColumnName, String indexedColumnName2, String indexedColumnName3) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        byte[] indexTableName2 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName2)/*TODO column family in index table*/);
        byte[] indexTableName3 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName3)/*TODO column family in index table*/);
        
/*        if (admin.isTableAvailable(testTableName) && admin.isTableAvailable(indexTableName)) {
        	admin.disableTable(testTableName);
        	admin.deleteTable(testTableName);
        	admin.disableTable(indexTableName);
        	admin.deleteTable(indexTableName);
        }*/
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName, indexedColumnName2, indexedColumnName3});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName2)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName2, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName3)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName3, Bytes.toBytes(columnFamily));
        }
    }
	
	class Reader extends Thread {
		
		String columnFamily = null;
		String column = null;
		String value = null;
		String sessionID = null;
		HTableGetByIndex table = null;
		
		public Reader(String columnFamily, String column, String value, String sessionID, HTableGetByIndex table) {
			this.columnFamily = columnFamily;
			this.column = column;
			this.value = value;
			this.sessionID = sessionID;
			this.table = table;
		}
	       
		public void run() {
			List<byte[]> res = new ArrayList<byte[]>();
			for (;;) {
				try {
					res = table.getByIndex(Bytes.toBytes(columnFamily), Bytes.toBytes(column), Bytes.toBytes(value));
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (SessionMap.sessionMap.get(sessionID) == null) {
			//		System.out.println(this.getName() + ": No session.");
				} else {
					if (SessionMap.sessionMap.get(sessionID).getProcess(columnFamily, column, value) == null) {
			//			System.out.println(this.getName() + ": SessionMap has no result.");
					} else {
						res.addAll(SessionMap.sessionMap.get(sessionID).getProcess(columnFamily, column, value));
					}					
				}
				
					
				if (res.isEmpty()) {
					System.out.println(this.getName() + ": No result.");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					continue;
				} else {
					try {
						res = deleteDuplicationList(res, table, Bytes.toBytes(value));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (res.isEmpty()) {
						System.out.println(this.getName() + ": No result.");
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						continue;
					}
					for (int i = 0; i < res.size(); i++) {
						System.out.println(this.getName() + ": Result " + i + " is " + Bytes.toString(res.get(i)));
					}
					break;
				}
			}
		}
	}
	
	private List<byte[]> deleteDuplicationList(List<byte[]> list, HTableGetByIndex table, byte[] val) throws IOException {
/*		List<byte[]> tmp = new ArrayList<byte[]>();
		for (Iterator<byte[]> iter = list.iterator(); iter.hasNext(); ) {
			byte[] element = iter.next();
			if (!tmp.contains(element)) {
				tmp.add(element);
			}
		}*/
		for (int i = 0; i < list.size() - 1; i++) {
			for (int j = list.size() - 1; j > i; j--) {
				if (Arrays.equals(list.get(i), list.get(j))) {
					list.remove(j);
				}
			}
		}
		if (!list.isEmpty()) {
			for (Iterator<byte[]> iter = list.iterator(); iter.hasNext();) {
				byte[] key = iter.next();
				if (!valueIsRight(table, key, val)) {
					iter.remove();
				}
			}
		}
		return list;
	}
	
	private boolean valueIsRight(HTableGetByIndex table, byte[] key, byte[] value) throws IOException {
		Get get = new Get(key);
		get.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName));
		Result result = table.get(get);
		for (KeyValue kv : result.list()) {
			if (Arrays.equals(kv.getValue(), value)) {
				return true;
			}
		}
		return false;
	}
	
	public void start() throws IOException {

		Configuration conf = HBaseConfiguration.create();
		HTableGetByIndex table = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
		table.configPolicy(HTableGetByIndex.PLY_FASTREAD);
		
		write(writeNum);
		System.out.println("queue:" + queue.size() + ", wait for 1 second...");
		for (int i = 0; i < writeNum; i++) {
			Put put = null;
			try {
				put = queue.poll(1, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (put == null) {
				break;
			}
/*			reader = new Reader[clientNum];
			for (int j = 0; j < clientNum; j++) {
				String value = Bytes.toString(
						put.get(Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)).get(0).getValue());
				reader[j] = new Reader(columnFamily, indexedColumnName, value, SessionIDs[j], table);
				reader[j].setName("Reader-" + j);
			}*/
			if (RYW) {
				Session session = new Session(SessionIDs[0]);
				SessionMap.sessionMap.put(SessionIDs[0], session);
				try {
					table.put(put, session);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				table.put(put);
			}
			System.out.println("Queue " + (i + 1) + " has been put");

/*			for (int j = clientNum - 1; j > -1; j--) {
				reader[j].start();
			}
			
			for (int j = 0; j < clientNum; j++) {
				try {
					reader[j].join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}*/
		}
	}
}
