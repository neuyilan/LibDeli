package tthbase.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Durability;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

import tthbase.client.HTableGetByIndex;
import tthbase.util.HIndexConstantsAndUtils;
import tthbase.util.Session;
import tthbase.util.SessionGenerate;
import tthbase.util.SessionMap;

public class PutPerformanceTest {

	static String filePath = "/opt/qhl/test-data/xaa1000.txt";
	static final boolean RYW = true;
	static final int GcTime = 30 * 60 * 1000;
	static  long writeNum = 10000000;
	static boolean wal = false;
	boolean stop = false;
	BlockingQueue<Put> queue = new LinkedBlockingQueue<Put>(1000000);
	
	Reader reader = null;
	Writer[] writer = null;
	static int writerNum = 20;
	long startTime = 0, lastStartTime = 0;
	long lastWriteCount = 0;
	int minWriteSpeed = Integer.MAX_VALUE;
	int maxWriteSpeed = 0;
	
	AtomicInteger writeCount = new AtomicInteger(0);
	
	static String testTableName = "table14";
	static String columnFamily = "cf";
	static String indexedColumnName = "c3";
	static String indexedColumnName2 = "c4";
	static String indexedColumnName3 = "c5";
	
	
	
	
	public static void initTables(Configuration conf, String testTableName, String columnFamily, String indexedColumnName) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName});
        }

        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
    }
	
	public static void initTables2(Configuration conf, String testTableName, String columnFamily, String indexedColumnName, String indexedColumnName2) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        byte[] indexTableName2 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName2)/*TODO column family in index table*/);
        
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName,indexedColumnName2});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName2)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName2, Bytes.toBytes(columnFamily));
        }
    }
	
	public static void initTables3(Configuration conf, String testTableName, String columnFamily, String indexedColumnName, String indexedColumnName2, String indexedColumnName3) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        byte[] indexTableName2 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName2)/*TODO column family in index table*/);
        byte[] indexTableName3 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName3)/*TODO column family in index table*/);
        
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName, indexedColumnName2, indexedColumnName3});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName2)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName2, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName3)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName3, Bytes.toBytes(columnFamily));
        }
    }
	
    public static void initCoProcessors(Configuration conf, String coprocessorJarLoc, HTableGetByIndex htable) throws Exception {
       int coprocessorIndex = 1;
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.IndexObserverwReadRepair");
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.PhysicalDeletionInCompaction");
       htable.configPolicy(HTableGetByIndex.PLY_READCHECK);
    }
    
    
    
	public static void main(String[] args) throws Exception {
		
		System.gc();
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.zookeeper.quorum", "data1,data2,data6,data7,data8");  
	    conf.set("hbase.zookeeper.property.clientPort", "2181");  

		if (args.length <= 0) {
			System.err.println("format: java -cp <classpath> tthbase.client.Demo <where coproc.jar is>");
			System.err.println(
					"example: java -cp build/jar/libDeli-client.jar:conf:lib/hbase-binding-0.1.4.jar tthbase.client.Demo  /root/app/deli/build/jar/libDeli-coproc.jar ");
			return;
		}
		String locCoproc = args[0];
		String coprocessorJarLoc = "file:" + locCoproc;
		
		//locCoproc = /opt/changxu/project/hbase-1.0.3/lib/libDeli-coproc.jar
		//coprocessorJarLoc = file:/opt/changxu/project/hbase-1.0.3/lib/libDeli-coproc.jar
		//

		initTables(conf, testTableName, columnFamily, indexedColumnName);
//		initTables2(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName2);
//		initTables3(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName2, indexedColumnName3);
//READ	
//		initTables2(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName3);
		
		HTableGetByIndex htable = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
//		initCoProcessors(conf, coprocessorJarLoc, htable);
	
		
		PutPerformanceTest test = new PutPerformanceTest();
		
		
//		writeNum = 5000000;
//		test.start();
//		writeNum = 10000000;
//		test.start();
		
		test.start();
		
		while (!test.stop || !test.queue.isEmpty()) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			test.report();
		}
		
		test.report();
	}
	
	class Reader extends Thread {
		
		private byte[] reverse(byte[] b){
			for (int i = 0, j = b.length - 1; i < j; i++, j--){
				byte tmp = b[i];
				b[i] = b[j];
				b[j] = tmp;
			}
			return b;
		}
		
		public void run() {
			stop = false;
			try {
				BufferedReader reader = new BufferedReader(new FileReader(new File(filePath)));
				String line = null, col[] = null;
				// 0 is for one key, 1 is for normal
				long i = 1;
				long hasWrite = 0;
				while ((line = reader.readLine()) != null && !stop) {
					col = line.split(";");
					// for 50%insert
					//			i ++;
					if (hasWrite > writeNum)
						break;
					hasWrite++;
					Put put = null;
					if (i % 2 != 0) {
						put = new Put(reverse(Bytes.toBytes(col[0])));
					} else {
						put = new Put(reverse(Bytes.toBytes("1")));
					}
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c1"), Bytes.toBytes(Integer.valueOf(col[1])));
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c2"), Bytes.toBytes(col[2]));
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c3"), Bytes.toBytes(col[3]));
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c4"), Bytes.toBytes(col[4]));
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c5"), Bytes.toBytes(col[5]));
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c6"), Bytes.toBytes(col[6]));
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c7"), Bytes.toBytes(Integer.valueOf(col[7])));
					put.add(Bytes.toBytes("cf"), Bytes.toBytes("c8"), Bytes.toBytes(col[8]));
					
					if (!wal) {
						put.setDurability(Durability.SKIP_WAL);
					}
					queue.put(put);
				}
				reader.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e){
				e.printStackTrace();
			}
			
			stop = true;
		}
	}
	
	class Writer extends Thread {
		
		String sessionID = "sessionid";
		int writerID = 0;
	    
	    public void setWriterID(int id) {
	    	this.writerID = id;
	    }
	       
		public void run() {
			try {
				Configuration conf = HBaseConfiguration.create();
				HTableGetByIndex htable = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
				for (;;) {
					Put put = queue.poll(1, TimeUnit.SECONDS);
					if (put == null) {
						if (stop) break;
						else continue;
					}
					if (RYW) {
						Session session = SessionMap.sessionMap.get(this.sessionID);
						if (session == null) {
							this.sessionID = SessionGenerate.generateSession();
							session = new Session(sessionID);
							SessionMap.sessionMap.put(sessionID, session);
						}
						htable.put(put, session);
					} else {
						htable.put(put);
					}
					writeCount.incrementAndGet();
				}
				htable.close();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void start() throws IOException {
    	stop = false;
    	reader = new Reader();
    	reader.setName("Reader");
    	reader.start();
		TimerTask gctimer = new gcTimer();
		Timer timer = new Timer(true);
    	
    	while (this.queue.size() < 500000) {
    		System.out.println("queue:" + queue.size() + ", wait for 1 second...");
    		try {
    			Thread.sleep(1000);
    		} catch (InterruptedException e){
    			e.printStackTrace();
    		}
    	}
    	
		timer.schedule(gctimer, GcTime, GcTime);
    	
    	writer = new Writer[writerNum];
    	for (int i = 0; i < writer.length; i++) {
    		writer[i] = new Writer();
    		writer[i].setName("Writer-" + i);
    		writer[i].setWriterID(i);
    		writer[i].start();
    	}
    	
    	startTime = System.currentTimeMillis();
    	lastStartTime = startTime;
    }
    
    public void stop() {
    	stop = true;
    	try {
    		reader.join();
    		for (int i = 0; i < writer.length; i++) {
    			writer[i].join();
    		}
    	} catch (InterruptedException e){
    		e.printStackTrace();
    	}
    }
    
    public void report() {
    	long curTime = System.currentTimeMillis();
    	if (curTime - startTime < 10) return;
    	
    	long curWriteCount = writeCount.intValue();
    	long curQueueSize =queue.size();
    	
    	int avgWriteSpeed = (int) (curWriteCount * 1000.0 / (curTime - startTime));
    	int lastWriteSpeed = 
    			(int) ((curWriteCount - lastWriteCount) * 1000.0 / (curTime - lastStartTime));
    	minWriteSpeed = lastWriteSpeed < minWriteSpeed ? lastWriteSpeed : minWriteSpeed;
    	maxWriteSpeed = lastWriteSpeed > maxWriteSpeed ? lastWriteSpeed : maxWriteSpeed;
    	
    	lastWriteCount = curWriteCount;
    	lastStartTime = curTime;
    	
    	System.out.println("time=" + ((curTime - startTime) / 1000) + ", write=" + curWriteCount + ", queue="
    			+ curQueueSize + ", avg=" + avgWriteSpeed + ", latest=" + lastWriteSpeed + ", min=" + minWriteSpeed
    			+ ", max=" + maxWriteSpeed);
    }
    
    class gcTimer extends TimerTask {

    	@Override
    	public void run() {
    		System.out.println("Start garbage collect...");
    		SessionMap.sessionMap.clear();

    	}
    }
}
