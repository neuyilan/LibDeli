package tthbase.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.util.Bytes;

import tthbase.client.HTableGetByIndex;
import tthbase.test.PutAccuracy.Reader;
import tthbase.util.SessionMap;

public class ReadProcess {
	
	Reader[] reader;
	int writeNum = 30000;
	static final int clientNum = 20;

	static String testTableName = "testtable3";
	static String columnFamily = "cf";
	static String indexedColumnName = "c3";
	static String indexedColumnName2 = "c4";
	static String indexedColumnName3 = "c5";
	
	public static void main(String[] args) {
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.zookeeper.quorum", "data1,data2,data6,data7,data8");  
	    conf.set("hbase.zookeeper.property.clientPort", "2181");  

		if (args.length <= 0) {
			System.err.println("format: java -cp <classpath> tthbase.client.Demo <where coproc.jar is>");
			System.err.println(
					"example: java -cp build/jar/libDeli-client.jar:conf:lib/hbase-binding-0.1.4.jar tthbase.client.Demo  /root/app/deli/build/jar/libDeli-coproc.jar ");
			return;
		}
		
		ReadProcess rp =new ReadProcess();
		rp.start();

	}
	
	public void start() {
		reader = new Reader[clientNum];
		for (int j = 0; j < clientNum; j++) {
			reader[j] = new Reader();
			reader[j].setName("Reader:" + j);
			reader[j].start();
		}
	}

	class Reader extends Thread {
	       
		public void run() {
			List<byte[]> res = new ArrayList<byte[]>();
			Configuration conf = HBaseConfiguration.create();
			HTableGetByIndex table = null;
			try {
				table = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
				table.configPolicy(HTableGetByIndex.PLY_FASTREAD);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			for (int value = 1; value <= writeNum; value++) {
				try {
					res = table.getByIndex(Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName), Bytes.toBytes(this.getName() + Integer.toString(value)));
					System.out.println(this.getName() + "-" + "query" + this.getName() + Integer.toString(value));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
