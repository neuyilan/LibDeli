package tthbase.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

import tthbase.client.HTableGetByIndex;
import tthbase.util.HIndexConstantsAndUtils;

public class ReadPerformance {
	
	static String testTableName = "table11";
	static String columnFamily = "cf";
	static String indexedColumnName = "c3";
	static String indexedColumnName2 = "c4";
	static String indexedColumnName3 = "c5";
	static String indexedValue = "100000.0";
	static String indexedValue3 = "1-URGENT";
	
	
	
	
	public static void initTables(Configuration conf, String testTableName, String columnFamily, String indexedColumnName) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName});
        }

        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
    }
	
	public static void initTables2(Configuration conf, String testTableName, String columnFamily, String indexedColumnName, String indexedColumnName2) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        byte[] indexTableName2 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName2)/*TODO column family in index table*/);
        
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName,indexedColumnName2});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName2)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName2, Bytes.toBytes(columnFamily));
        }
    }
	
	public static void initTables3(Configuration conf, String testTableName, String columnFamily, String indexedColumnName, String indexedColumnName2, String indexedColumnName3) throws Exception{
        HBaseAdmin admin = new HBaseAdmin(conf);
        byte[] indexTableName = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName)/*TODO column family in index table*/);
        byte[] indexTableName2 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName2)/*TODO column family in index table*/);
        byte[] indexTableName3 = HIndexConstantsAndUtils.generateIndexTableName(Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName3)/*TODO column family in index table*/);
        
        
        if (!admin.isTableAvailable(testTableName)){
            HIndexConstantsAndUtils.createAndConfigBaseTable(conf, Bytes.toBytes(testTableName), Bytes.toBytes(columnFamily), new String[]{indexedColumnName, indexedColumnName2, indexedColumnName3});
        }
        

        if (!admin.isTableAvailable(indexTableName)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName2)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName2, Bytes.toBytes(columnFamily));
        }
        
        if (!admin.isTableAvailable(indexTableName3)){
            HIndexConstantsAndUtils.createAndConfigIndexTable(conf, indexTableName3, Bytes.toBytes(columnFamily));
        }
    }
	
    public static void initCoProcessors(Configuration conf, String coprocessorJarLoc, HTableGetByIndex htable) throws Exception {
       int coprocessorIndex = 1;
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.IndexObserverwReadRepair");
       HIndexConstantsAndUtils.updateCoprocessor(conf, htable.getTableName(), coprocessorIndex++, true, coprocessorJarLoc, "tthbase.coprocessor.PhysicalDeletionInCompaction");
       htable.configPolicy(HTableGetByIndex.PLY_READCHECK);
    }

	public static void main(String[] args) throws Exception {
		
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.zookeeper.quorum", "data1,data2,data6,data7,data8");  
	    conf.set("hbase.zookeeper.property.clientPort", "2181");  

		if (args.length <= 0) {
			System.err.println("format: java -cp <classpath> tthbase.client.Demo <where coproc.jar is>");
			System.err.println(
					"example: java -cp build/jar/libDeli-client.jar:conf:lib/hbase-binding-0.1.4.jar tthbase.client.Demo  /root/app/deli/build/jar/libDeli-coproc.jar ");
			return;
		}
		String locCoproc = args[0];
		String coprocessorJarLoc = "file:" + locCoproc;

//		initTables(conf, testTableName, columnFamily, indexedColumnName);
//		initTables2(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName2);
//		initTables3(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName2, indexedColumnName3);
// READ
		initTables2(conf, testTableName, columnFamily, indexedColumnName, indexedColumnName3);
		HTableGetByIndex htable = new HTableGetByIndex(conf, Bytes.toBytes(testTableName));
		initCoProcessors(conf, coprocessorJarLoc, htable);
		
		long starttime = System.currentTimeMillis();
		htable.configPolicy(HTableGetByIndex.PLY_FASTREAD);
	    List<byte[]> res1 = htable.getByIndex(Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName3), Bytes.toBytes(indexedValue3));
	    System.out.println("res1 is " + res1.size());
	    Map<byte[], List<byte[]>> res2 = htable.getByIndexByRange(Bytes.toBytes(columnFamily), Bytes.toBytes(indexedColumnName),Bytes.toBytes("0") ,Bytes.toBytes(indexedValue));
	    System.out.println("res2 is " + res2.size());
	    List<byte[]> res3 = new ArrayList<byte[]>(); 
	    for (Map.Entry<byte[], List<byte[]>> entry : res2.entrySet()) {
	    	List<byte[]> restmp = entry.getValue();
	    	for (int i = 0;i < restmp.size();i++) {
	    		if (!res3.contains(restmp.get(i))) {
	    			res3.add(restmp.get(i));
	    		}
	    	}
	    }
	    System.out.println("res3 is " + res3.size());
	    if (res1 != null) {
	    	res1.addAll(res3);
	    } 
	    System.out.println("res1 is " + res1.size());
	    assert(res1 != null && res1.size() != 0);
	       System.out.println("Throughout is " + res1.size()*1000/(System.currentTimeMillis()-starttime));

	}

}
