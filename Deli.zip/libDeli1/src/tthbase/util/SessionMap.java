package tthbase.util;

import java.util.HashMap;
import java.util.Map;

public class SessionMap {
	public static Map<String,Session> sessionMap = new HashMap<String,Session>();
	public static String[] sessionIdList = new String[50];
}
