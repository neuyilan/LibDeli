package tthbase.util;

import java.io.IOException;
import java.lang.String;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;


public class Session {
	
	private String sessionId = null;
	private long liveTime = 0;
	private Map<String,List<byte[]>> kvMap = null;
	private final long minute = 60000;
	
	public Session(String sessionId){
		this.sessionId = sessionId;
		this.liveTime = System.currentTimeMillis();
		this.kvMap = new HashMap<String,List<byte[]>>();
	}

	public void putProcess(HTableDescriptor dataTableDesc,Put put){
        
        byte[] dataKey = put.getRow();
        
        for (int index = 1; ; index++) {
            String fullpathOfIndexedcolumnInDatatable = dataTableDesc.getValue(HIndexConstantsAndUtils.INDEX_INDICATOR + index);
            if(fullpathOfIndexedcolumnInDatatable == null){
                //no (further) index column, stop at current index
                break;
            } else {
                String[] datatableColumnPath = fullpathOfIndexedcolumnInDatatable.split("\\|");
                String indexedColumnFamily = datatableColumnPath[0];
                String indexedColumnName = datatableColumnPath[1]; 
                byte[] dataValuePerColumn = getColumnValue(put, Bytes.toBytes(indexedColumnFamily), Bytes.toBytes(indexedColumnName));
                if(dataValuePerColumn != null){
                	String generatedKey = indexedColumnFamily + "_" + indexedColumnName + "_" + Bytes.toString(dataValuePerColumn);
                	updateKVmap(generatedKey, dataKey);
                } else {
                    //the indexed column (family) is not associated with the put, to continue.
                    continue;
                }
            }
        }

	}
	
	public List<byte[]> getProcess(String indexedColumnFamily,String indexedColumnName,String value){
		String generatedKey = indexedColumnFamily + "_" + indexedColumnName + "_" + value;
		return kvMap.get(generatedKey);
	}
	
	private byte[] getColumnValue(final Put put, byte[] columnFamily, byte[] columnName){
		
        if(!put.has(columnFamily, columnName)){
            return null;
        }

        List<Cell> values = put.get(columnFamily, columnName);
        if (values == null || values.isEmpty()) {
            throw new RuntimeException("TTERROR_" + "SESSION_PUTPROCESS" + ": " + "empty value lists while put.has() returns true!");
        }

        //should be one element in values, since column qualifier is an exact name, matching one column; also one version of value is expected.
        if (values.size() != 1) {
            throw new RuntimeException("TTERROR_" + "SESSION_PUTPROCESS" + ": " + "multiple versions of values or multiple columns by qualier in put()!");
        }

//TOREMOVE to get timestamp, refer to old project code.
        Cell cur = values.get(0);
        byte[] value = cur.getValue();
        return value;
    }
	
	
	public boolean checkTime(long currentTime){
		if ((currentTime - this.liveTime) > (30 * minute)){
			return false;
		}else{
			return true;
		}
	}
	
	
	private void updateKVmap(String colvalue,byte[] rowkey){
		
		if(kvMap.get(colvalue) == null){
            List<byte[]> results = new ArrayList<byte[]>();
            results.add(rowkey);
            kvMap.put(colvalue, results);
        } else {
            kvMap.get(colvalue).add(rowkey);
        }
		updateTime(System.currentTimeMillis());
	}
	
	private long updateTime(long newTime){
		this.liveTime = newTime;
		return newTime;
	}
	
	public String getSessionId(){
		return this.sessionId;
	}
	
	public void gcKvmap(){
		this.kvMap = null;
	}
	
}
